"""Yahoo Finance integration built on yfinance.

All functions raise fastapi.HTTPException (404/503) on failure so routes
stay thin. Missing Yahoo fields become None instead of crashing.
"""

from datetime import date
from typing import Any, Dict, List, Optional

import pandas as pd
import yfinance as yf
from fastapi import HTTPException

from app.utils.helpers import (
    clean_value,
    normalize_symbol,
    safe_float,
    safe_int,
    safe_str,
    validate_symbol_format,
)


def _ensure_valid_symbol(symbol: str) -> str:
    cleaned = normalize_symbol(symbol)
    error = validate_symbol_format(symbol)
    if error:
        raise HTTPException(status_code=400, detail=error)
    return cleaned


def _fetch_info(symbol: str) -> Dict[str, Any]:
    """Fetch ticker info dict. Raises 503 on transport errors."""
    cleaned = _ensure_valid_symbol(symbol)
    ticker = yf.Ticker(cleaned)
    info: Dict[str, Any] = {}
    try:
        # get_info() is the modern API; fall back to .info for older versions.
        if hasattr(ticker, "get_info"):
            try:
                info = ticker.get_info() or {}
            except Exception:
                info = {}
        if not info:
            try:
                info = ticker.info or {}
            except Exception:
                info = {}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Yahoo Finance service unavailable: {exc}",
        )
    if not isinstance(info, dict):
        info = {}
    return info


def _looks_like_unknown_symbol(info: Dict[str, Any], symbol: str) -> bool:
    """Heuristic: Yahoo returns an almost-empty dict for bogus symbols."""
    if not info:
        return True
    meaningful_keys = (
        "longName",
        "shortName",
        "displayName",
        "symbol",
        "regularMarketPrice",
        "currentPrice",
        "previousClose",
        "exchange",
        "quoteType",
        "sector",
        "industry",
        "country",
        "marketCap",
    )
    present = [k for k in meaningful_keys if info.get(k) not in (None, "", 0)]
    if not present:
        return True
    # Extra guard: Yahoo sometimes echoes the requested symbol with nothing else.
    returned_symbol = str(info.get("symbol") or info.get("ticker") or "").upper()
    if returned_symbol and returned_symbol != symbol.upper() and len(present) <= 1:
        return True
    return False


def _confirm_symbol_has_data(symbol: str, info: Dict[str, Any]) -> None:
    """Raise 404 if Yahoo clearly has no data for this symbol."""
    if not _looks_like_unknown_symbol(info, symbol):
        return
    # Second chance: fast_info / recent history may exist for valid symbols
    # whose info dict is sparse (e.g. indices, ETFs).
    try:
        ticker = yf.Ticker(symbol)
        if hasattr(ticker, "fast_info"):
            try:
                fast = ticker.fast_info
                price = None
                if isinstance(fast, dict):
                    price = fast.get("last_price")
                else:
                    price = getattr(fast, "last_price", None)
                if price is not None:
                    return
            except Exception:
                pass
        hist = ticker.history(period="5d", auto_adjust=False)
        if hist is not None and not hist.empty:
            return
    except Exception:
        pass
    raise HTTPException(
        status_code=404,
        detail=f"No data found for symbol '{symbol}'. It may be invalid or delisted.",
    )


def _fast_info_dict(symbol: str) -> Dict[str, Any]:
    """Best-effort snapshot from yfinance fast_info (different Yahoo endpoint).

    Returns {} when unavailable. Never raises.
    """
    try:
        fast = yf.Ticker(symbol).fast_info
        if isinstance(fast, dict):
            return dict(fast)
        data: Dict[str, Any] = {}
        for key in (
            "currency",
            "day_high",
            "day_low",
            "exchange",
            "last_price",
            "last_volume",
            "market_cap",
            "open",
            "previous_close",
            "quote_type",
            "regular_market_previous_close",
            "shares",
            "timezone",
            "year_high",
            "year_low",
            "fifty_day_average",
            "two_hundred_day_average",
        ):
            try:
                data[key] = getattr(fast, key, None)
            except Exception:
                pass
        # Also accept camelCase attribute names used by some yfinance versions.
        for key in ("dayHigh", "dayLow", "lastPrice", "lastVolume", "marketCap",
                    "previousClose", "quoteType", "yearHigh", "yearLow"):
            if key not in data:
                try:
                    data[key] = getattr(fast, key, None)
                except Exception:
                    pass
        return data
    except Exception:
        return {}


def _first_float(*values: Any) -> Optional[float]:
    for value in values:
        result = safe_float(value)
        if result is not None:
            return result
    return None


def _first_int(*values: Any) -> Optional[int]:
    for value in values:
        result = safe_int(value)
        if result is not None:
            return result
    return None


def _first_str(*values: Any) -> Optional[str]:
    for value in values:
        result = safe_str(value)
        if result is not None:
            return result
    return None


def get_company_info(symbol: str) -> Dict[str, Any]:
    cleaned = _ensure_valid_symbol(symbol)
    try:
        info = _fetch_info(cleaned)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Yahoo Finance error: {exc}")
    _confirm_symbol_has_data(cleaned, info)
    fast = _fast_info_dict(cleaned)

    officers_raw = info.get("companyOfficers")
    officers: List[Dict[str, Optional[str]]] = []
    if isinstance(officers_raw, list):
        for entry in officers_raw:
            if not isinstance(entry, dict):
                continue
            officers.append(
                {
                    "name": safe_str(entry.get("name")),
                    "title": safe_str(entry.get("title")),
                }
            )

    return {
        "symbol": safe_str(info.get("symbol")) or cleaned,
        "name": safe_str(info.get("longName"))
        or safe_str(info.get("shortName"))
        or safe_str(info.get("displayName")),
        "business_summary": safe_str(info.get("longBusinessSummary")),
        "industry": safe_str(info.get("industry")),
        "sector": safe_str(info.get("sector")),
        "country": safe_str(info.get("country")),
        "website": safe_str(info.get("website")),
        "exchange": _first_str(info.get("exchange"), info.get("fullExchangeName"), fast.get("exchange")),
        "currency": _first_str(info.get("currency"), info.get("financialCurrency"), fast.get("currency")),
        "market": safe_str(info.get("market")),
        "quote_type": _first_str(info.get("quoteType"), info.get("quote_type"), fast.get("quoteType"), fast.get("quote_type")),
        "officers": officers,
    }


def get_stock_data(symbol: str) -> Dict[str, Any]:
    cleaned = _ensure_valid_symbol(symbol)
    try:
        info = _fetch_info(cleaned)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Yahoo Finance error: {exc}")
    _confirm_symbol_has_data(cleaned, info)
    fast = _fast_info_dict(cleaned)

    price = _first_float(
        info.get("regularMarketPrice"), info.get("currentPrice"),
        fast.get("last_price"), fast.get("lastPrice"),
    )
    previous_close = _first_float(
        info.get("regularMarketPreviousClose"), info.get("previousClose"),
        fast.get("regular_market_previous_close"), fast.get("previous_close"),
        fast.get("previousClose"),
    )

    # Prefer Yahoo's change fields, otherwise compute from price/previous close.
    change = safe_float(info.get("regularMarketChange"))
    change_percent = safe_float(info.get("regularMarketChangePercent"))
    if change is None and price is not None and previous_close is not None:
        change = round(price - previous_close, 4)
    if change_percent is None and price is not None and previous_close not in (None, 0):
        try:
            change_percent = round((price - previous_close) / previous_close * 100, 4)
        except Exception:
            change_percent = None

    volume = _first_int(
        info.get("regularMarketVolume"), info.get("volume"),
        fast.get("last_volume"), fast.get("lastVolume"),
    )

    return {
        "symbol": safe_str(info.get("symbol")) or cleaned,
        "name": safe_str(info.get("longName"))
        or safe_str(info.get("shortName"))
        or safe_str(info.get("displayName")),
        "market_state": safe_str(info.get("marketState")),
        "regular_market_price": price,
        "previous_close": previous_close,
        "price_change": change,
        "price_change_percent": change_percent,
        "day_high": _first_float(info.get("regularMarketDayHigh"), info.get("dayHigh"), fast.get("day_high"), fast.get("dayHigh")),
        "day_low": _first_float(info.get("regularMarketDayLow"), info.get("dayLow"), fast.get("day_low"), fast.get("dayLow")),
        "fifty_two_week_high": _first_float(info.get("fiftyTwoWeekHigh"), fast.get("year_high"), fast.get("yearHigh")),
        "fifty_two_week_low": _first_float(info.get("fiftyTwoWeekLow"), fast.get("year_low"), fast.get("yearLow")),
        "volume": volume,
        "market_cap": _first_int(info.get("marketCap"), fast.get("market_cap"), fast.get("marketCap")),
        "currency": _first_str(info.get("currency"), info.get("financialCurrency"), fast.get("currency")),
        "exchange": _first_str(info.get("exchange"), info.get("fullExchangeName"), fast.get("exchange")),
    }


def _flatten_columns(df: pd.DataFrame) -> pd.DataFrame:
    """yfinance may return MultiIndex columns; flatten to single level."""
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]
    return df


def get_history(symbol: str, start: date, end: date) -> List[Dict[str, Any]]:
    cleaned = _ensure_valid_symbol(symbol)
    if start >= end:
        raise HTTPException(status_code=400, detail="start_date must be before end_date.")
    try:
        ticker = yf.Ticker(cleaned)
        df = ticker.history(
            start=start.isoformat(),
            end=end.isoformat(),
            auto_adjust=False,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Yahoo Finance service unavailable: {exc}",
        )
    if df is None or df.empty:
        raise HTTPException(
            status_code=404,
            detail=f"No historical data found for symbol '{cleaned}' in the given date range.",
        )
    df = _flatten_columns(df)
    # Normalize index to dates.
    try:
        df.index = pd.to_datetime(df.index)
    except Exception:
        pass

    bars: List[Dict[str, Any]] = []
    adj_col = "Adj Close" if "Adj Close" in df.columns else ("Adj_Close" if "Adj_Close" in df.columns else None)
    for idx, row in df.iterrows():
        try:
            date_str = pd.Timestamp(idx).date().isoformat()
        except Exception:
            date_str = clean_value(idx)
            if date_str is None:
                continue
            date_str = str(date_str)
        close_val = safe_float(row.get("Close"))
        adj_val = safe_float(row.get(adj_col)) if adj_col else None
        if adj_val is None:
            adj_val = close_val
        bars.append(
            {
                "date": date_str,
                "open": safe_float(row.get("Open")),
                "high": safe_float(row.get("High")),
                "low": safe_float(row.get("Low")),
                "close": close_val,
                "adj_close": adj_val,
                "volume": safe_int(row.get("Volume")),
            }
        )
    if not bars:
        raise HTTPException(
            status_code=404,
            detail=f"No historical data found for symbol '{cleaned}' in the given date range.",
        )
    return bars


def get_analysis(symbol: str, start: date, end: date) -> Dict[str, Any]:
    """Compute summary statistics over historical closes/volumes."""
    bars = get_history(symbol, start, end)
    cleaned = normalize_symbol(symbol)

    closes = [b["close"] for b in bars if b.get("close") is not None]
    volumes = [b["volume"] for b in bars if b.get("volume") is not None]
    if not closes:
        raise HTTPException(
            status_code=404,
            detail=f"No closing-price data available for '{cleaned}' in the given range.",
        )

    starting_price = closes[0]
    ending_price = closes[-1]
    highest_price = max(closes)
    lowest_price = min(closes)
    average_close = round(sum(closes) / len(closes), 4)

    total_return_percent: Optional[float] = None
    if starting_price not in (None, 0):
        total_return_percent = round((ending_price - starting_price) / starting_price * 100, 4)

    # Volatility = sample std dev of daily simple returns, in percent.
    volatility: Optional[float] = None
    returns: List[float] = []
    for prev, cur in zip(closes, closes[1:]):
        if prev not in (None, 0) and cur is not None:
            try:
                returns.append((cur - prev) / prev)
            except Exception:
                continue
    if len(returns) >= 2:
        import statistics

        try:
            volatility = round(statistics.stdev(returns) * 100, 4)
        except Exception:
            volatility = None
    elif len(returns) == 1:
        volatility = 0.0

    average_volume: Optional[float] = None
    if volumes:
        average_volume = round(sum(volumes) / len(volumes), 2)

    # Daily moves based on close vs open where both exist, else close-vs-prev-close.
    positive_days = 0
    negative_days = 0
    daily_changes: List[Dict[str, Any]] = []
    prev_close: Optional[float] = None
    for b in bars:
        pct: Optional[float] = None
        if b.get("open") not in (None, 0) and b.get("close") is not None:
            try:
                pct = (b["close"] - b["open"]) / b["open"] * 100
            except Exception:
                pct = None
        elif prev_close not in (None, 0) and b.get("close") is not None:
            try:
                pct = (b["close"] - prev_close) / prev_close * 100
            except Exception:
                pct = None
        if pct is not None:
            if pct > 0:
                positive_days += 1
            elif pct < 0:
                negative_days += 1
            daily_changes.append({"date": b["date"], "change_percent": round(pct, 4), "close": b["close"]})
        if b.get("close") is not None:
            prev_close = b["close"]

    best_day = max(daily_changes, key=lambda d: d["change_percent"]) if daily_changes else None
    worst_day = min(daily_changes, key=lambda d: d["change_percent"]) if daily_changes else None

    ma20: Optional[float] = None
    ma50: Optional[float] = None
    if len(closes) >= 20:
        ma20 = round(sum(closes[-20:]) / 20, 4)
    if len(closes) >= 50:
        ma50 = round(sum(closes[-50:]) / 50, 4)

    # Trend: compare ending vs starting with a 2% dead-band for "sideways".
    trend = "sideways"
    if total_return_percent is not None:
        if total_return_percent > 2:
            trend = "upward"
        elif total_return_percent < -2:
            trend = "downward"

    # Data-driven insight (no financial advice).
    parts = [f"From {start.isoformat()} to {end.isoformat()}, {cleaned} showed a {trend} trend"]
    if total_return_percent is not None:
        parts[0] += f" with a total return of {total_return_percent}%"
    parts[0] += f" over {len(bars)} trading days."
    if volatility is not None:
        level = "low" if volatility < 1 else ("moderate" if volatility < 2.5 else "high")
        parts.append(f"Volatility (std dev of daily returns) was {volatility}%, which is relatively {level} for this period.")
    if ma20 is not None and ending_price is not None:
        pos = "above" if ending_price > ma20 else ("below" if ending_price < ma20 else "at")
        parts.append(f"The ending price ({ending_price}) closed {pos} the 20-day moving average ({ma20}).")
    if ma50 is not None and ending_price is not None:
        pos = "above" if ending_price > ma50 else ("below" if ending_price < ma50 else "at")
        parts.append(f"The ending price closed {pos} the 50-day moving average ({ma50}).")
    elif ma20 is None:
        parts.append("Not enough trading days in this range to compute a 20-day moving average.")
    parts.append(f"Positive trading days: {positive_days}; negative trading days: {negative_days}.")

    return {
        "symbol": cleaned,
        "start_date": start.isoformat(),
        "end_date": end.isoformat(),
        "trading_days": len(bars),
        "starting_price": starting_price,
        "ending_price": ending_price,
        "highest_price": highest_price,
        "lowest_price": lowest_price,
        "total_return_percent": total_return_percent,
        "average_close": average_close,
        "volatility": volatility,
        "average_volume": average_volume,
        "positive_days": positive_days,
        "negative_days": negative_days,
        "best_day": best_day,
        "worst_day": worst_day,
        "trend": trend,
        "moving_average_20": ma20,
        "moving_average_50": ma50,
        "insight": " ".join(parts),
        "disclaimer": (
            "This is analytical information based on historical data only, "
            "not investment advice or a prediction of future performance."
        ),
    }
