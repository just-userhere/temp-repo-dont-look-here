"""Pydantic request/response models."""

from datetime import date
from typing import Any, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from app.utils.helpers import normalize_symbol, validate_symbol_format


class HistoricalRequest(BaseModel):
    symbol: str = Field(
        ...,
        description="Company stock symbol, e.g. AAPL",
        examples=["AAPL"],
    )
    start_date: date = Field(
        ...,
        description="Start date (inclusive) in YYYY-MM-DD format",
        examples=["2025-01-01"],
    )
    end_date: date = Field(
        ...,
        description="End date (exclusive in Yahoo Finance, inclusive in response) in YYYY-MM-DD format",
        examples=["2025-06-30"],
    )

    @field_validator("symbol")
    @classmethod
    def validate_symbol(cls, v: str) -> str:
        error = validate_symbol_format(v)
        if error:
            raise ValueError(error)
        return normalize_symbol(v)

    @model_validator(mode="after")
    def validate_date_range(self) -> "HistoricalRequest":
        if self.start_date >= self.end_date:
            raise ValueError("start_date must be before end_date.")
        return self


class CompanyOfficer(BaseModel):
    name: Optional[str] = None
    title: Optional[str] = None


class CompanyResponse(BaseModel):
    symbol: str
    name: Optional[str] = None
    business_summary: Optional[str] = None
    industry: Optional[str] = None
    sector: Optional[str] = None
    country: Optional[str] = None
    website: Optional[str] = None
    exchange: Optional[str] = None
    currency: Optional[str] = None
    market: Optional[str] = None
    quote_type: Optional[str] = None
    officers: List[CompanyOfficer] = Field(default_factory=list)


class StockResponse(BaseModel):
    symbol: str
    name: Optional[str] = None
    market_state: Optional[str] = None
    regular_market_price: Optional[float] = None
    previous_close: Optional[float] = None
    price_change: Optional[float] = None
    price_change_percent: Optional[float] = None
    day_high: Optional[float] = None
    day_low: Optional[float] = None
    fifty_two_week_high: Optional[float] = None
    fifty_two_week_low: Optional[float] = None
    volume: Optional[int] = None
    market_cap: Optional[int] = None
    currency: Optional[str] = None
    exchange: Optional[str] = None


class HistoricalBar(BaseModel):
    date: str
    open: Optional[float] = None
    high: Optional[float] = None
    low: Optional[float] = None
    close: Optional[float] = None
    adj_close: Optional[float] = Field(default=None, alias="adj_close")

    model_config = {"populate_by_name": True}


class HistoricalResponse(BaseModel):
    symbol: str
    start_date: str
    end_date: str
    count: int
    data: List[HistoricalBar]


class AnalysisResponse(BaseModel):
    symbol: str
    start_date: str
    end_date: str
    trading_days: int
    starting_price: Optional[float] = None
    ending_price: Optional[float] = None
    highest_price: Optional[float] = None
    lowest_price: Optional[float] = None
    total_return_percent: Optional[float] = None
    average_close: Optional[float] = None
    volatility: Optional[float] = None
    average_volume: Optional[float] = None
    positive_days: int = 0
    negative_days: int = 0
    best_day: Optional[dict[str, Any]] = None
    worst_day: Optional[dict[str, Any]] = None
    trend: Optional[str] = None
    moving_average_20: Optional[float] = None
    moving_average_50: Optional[float] = None
    insight: str = ""
    disclaimer: str = (
        "This is analytical information based on historical data only, "
        "not investment advice or a prediction of future performance."
    )
