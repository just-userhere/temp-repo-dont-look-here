"""Shared helpers: symbol validation and JSON-safe conversion."""

import math
import re
from datetime import date, datetime
from typing import Any, Optional

import numpy as np
import pandas as pd

# Yahoo symbols: letters, digits, dots, dashes, carets (indices like ^GSPC), equals (futures like GC=F).
_SYMBOL_RE = re.compile(r"^[A-Za-z0-9.\-=\^]+$")


def normalize_symbol(symbol: str) -> str:
    """Strip whitespace and uppercase a symbol. Returns '' for non-strings."""
    if not isinstance(symbol, str):
        return ""
    return symbol.strip().upper()


def validate_symbol_format(symbol: str) -> Optional[str]:
    """Return an error message if the symbol format is invalid, else None."""
    cleaned = normalize_symbol(symbol)
    if not cleaned:
        return "Symbol must be a non-empty string."
    if len(cleaned) > 20:
        return "Symbol must be 20 characters or fewer."
    if not _SYMBOL_RE.match(cleaned):
        return "Symbol contains invalid characters. Use letters, digits, '.', '-', '=' or '^'."
    return None


def clean_value(value: Any) -> Any:
    """Convert pandas/numpy/datetime values into JSON-serializable values.

    - NaN / NaT / None / NaT-like -> None
    - numpy scalars -> native Python scalars
    - Timestamps / datetime / date -> ISO-8601 date string (YYYY-MM-DD for dates)
    - floats that are NaN/inf -> None
    """
    if value is None:
        return None
    # pandas NA / NaT singletons
    if value is pd.NA or value is pd.NaT:
        return None
    # numpy generic scalars
    if isinstance(value, np.generic):
        try:
            value = value.item()
        except Exception:
            return None
    # numpy arrays -> list
    if isinstance(value, np.ndarray):
        return [clean_value(v) for v in value.tolist()]
    # pandas Timestamp
    if isinstance(value, pd.Timestamp):
        if pd.isna(value):
            return None
        return value.date().isoformat()
    # datetime -> date string if midnight else isoformat
    if isinstance(value, datetime):
        try:
            if pd.isna(value):
                return None
        except Exception:
            pass
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    # float NaN/inf
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
        return value
    # strings: empty string stays as-is (caller decides); bytes decode
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8", errors="replace")
        except Exception:
            return None
    # ints, bools, strings pass through
    if isinstance(value, (int, bool, str)):
        return value
    # Last resort: pandas-style NA check
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass
    return value


def safe_float(value: Any) -> Optional[float]:
    cleaned = clean_value(value)
    if cleaned is None:
        return None
    try:
        result = float(cleaned)
    except (TypeError, ValueError):
        return None
    if math.isnan(result) or math.isinf(result):
        return None
    return result


def safe_int(value: Any) -> Optional[int]:
    cleaned = clean_value(value)
    if cleaned is None:
        return None
    try:
        # Handles "123.0" style strings and floats.
        result = int(float(cleaned))
    except (TypeError, ValueError):
        return None
    return result


def safe_str(value: Any) -> Optional[str]:
    cleaned = clean_value(value)
    if cleaned is None:
        return None
    if isinstance(cleaned, str):
        cleaned = cleaned.strip()
        return cleaned if cleaned else None
    return str(cleaned)
