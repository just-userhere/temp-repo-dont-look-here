"""POST /api/historical — historical OHLCV bars."""

from fastapi import APIRouter, Body

from app.models import HistoricalRequest, HistoricalResponse
from app.services import yahoo_finance as svc

router = APIRouter(prefix="/api/historical", tags=["Historical"])

_EXAMPLE = {"symbol": "AAPL", "start_date": "2025-01-01", "end_date": "2025-06-30"}


@router.post(
    "",
    response_model=HistoricalResponse,
    summary="Get historical market data",
    description="Returns daily OHLCV history for a symbol between start_date and end_date.",
    responses={
        200: {"description": "Historical data retrieved successfully."},
        400: {"description": "Invalid request (bad dates or symbol)."},
        404: {"description": "Symbol or historical data not found."},
        422: {"description": "Validation error."},
        503: {"description": "Yahoo Finance service unavailable."},
    },
)
def get_historical(
    payload: HistoricalRequest = Body(
        ...,
        examples=[_EXAMPLE],
    ),
) -> HistoricalResponse:
    bars = svc.get_history(payload.symbol, payload.start_date, payload.end_date)
    return HistoricalResponse(
        symbol=payload.symbol,
        start_date=payload.start_date.isoformat(),
        end_date=payload.end_date.isoformat(),
        count=len(bars),
        data=bars,  # type: ignore[arg-type]
    )
