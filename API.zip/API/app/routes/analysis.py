"""POST /api/analysis — data-driven insights over historical data."""

from fastapi import APIRouter, Body

from app.models import AnalysisResponse, HistoricalRequest
from app.services import yahoo_finance as svc

router = APIRouter(prefix="/api/analysis", tags=["Analysis"])

_EXAMPLE = {"symbol": "AAPL", "start_date": "2025-01-01", "end_date": "2025-06-30"}


@router.post(
    "",
    response_model=AnalysisResponse,
    summary="Get analytical insights",
    description=(
        "Computes descriptive statistics (returns, volatility, moving averages, "
        "best/worst days, trend) over historical data. "
        "Analytical information only — not investment advice."
    ),
    responses={
        200: {"description": "Analysis computed successfully."},
        400: {"description": "Invalid request (bad dates or symbol)."},
        404: {"description": "Symbol or historical data not found."},
        422: {"description": "Validation error."},
        503: {"description": "Yahoo Finance service unavailable."},
    },
)
def get_analysis(
    payload: HistoricalRequest = Body(
        ...,
        examples=[_EXAMPLE],
    ),
) -> AnalysisResponse:
    result = svc.get_analysis(payload.symbol, payload.start_date, payload.end_date)
    return AnalysisResponse(**result)
