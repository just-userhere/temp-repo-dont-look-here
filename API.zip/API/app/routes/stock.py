"""GET /api/stock/{symbol} — current/latest market data."""

from fastapi import APIRouter, HTTPException, Path

from app.models import StockResponse
from app.services import yahoo_finance as svc
from app.utils.helpers import normalize_symbol, validate_symbol_format

router = APIRouter(prefix="/api/stock", tags=["Stock"])


@router.get(
    "/{symbol}",
    response_model=StockResponse,
    summary="Get current stock market data",
    description="Returns the latest available market data for a stock symbol using Yahoo Finance data.",
    responses={
        200: {"description": "Stock data retrieved successfully."},
        400: {"description": "Invalid symbol format."},
        404: {"description": "Symbol not found."},
        503: {"description": "Yahoo Finance service unavailable."},
    },
)
def get_stock(
    symbol: str = Path(..., description="Stock symbol, e.g. AAPL", examples=["AAPL"]),
) -> StockResponse:
    error = validate_symbol_format(symbol)
    if error:
        raise HTTPException(status_code=400, detail=error)
    data = svc.get_stock_data(normalize_symbol(symbol))
    return StockResponse(**data)
