"""GET /api/company/{symbol} — detailed company information."""

from fastapi import APIRouter, HTTPException, Path

from app.models import CompanyResponse
from app.services import yahoo_finance as svc
from app.utils.helpers import normalize_symbol, validate_symbol_format

router = APIRouter(prefix="/api/company", tags=["Company"])


@router.get(
    "/{symbol}",
    response_model=CompanyResponse,
    summary="Get company information",
    description="Returns detailed company information for a valid stock symbol using Yahoo Finance data.",
    responses={
        200: {"description": "Company information retrieved successfully."},
        400: {"description": "Invalid symbol format."},
        404: {"description": "Symbol not found."},
        503: {"description": "Yahoo Finance service unavailable."},
    },
)
def get_company(
    symbol: str = Path(..., description="Stock symbol, e.g. AAPL", examples=["AAPL"]),
) -> CompanyResponse:
    error = validate_symbol_format(symbol)
    if error:
        raise HTTPException(status_code=400, detail=error)
    data = svc.get_company_info(normalize_symbol(symbol))
    return CompanyResponse(**data)
