"""FastAPI application entrypoint."""

from fastapi import FastAPI, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.routes import analysis, company, historical, stock

app = FastAPI(
    title="Company & Market Data API",
    description=(
        "REST API for company information, current stock market data, "
        "historical market data, and analytical insights powered by Yahoo Finance (yfinance). "
        "All analysis is descriptive and data-driven — not investment advice."
    ),
    version="1.0.0",
)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={"detail": "Validation error.", "errors": jsonable_encoder(exc.errors())},
    )


@app.get("/", tags=["Health"], summary="API root")
def root():
    return {
        "name": "Company & Market Data API",
        "version": "1.0.0",
        "docs": "/docs",
        "redoc": "/redoc",
        "endpoints": [
            "GET /api/company/{symbol}",
            "GET /api/stock/{symbol}",
            "POST /api/historical",
            "POST /api/analysis",
        ],
    }


@app.get("/health", tags=["Health"], summary="Health check")
def health():
    return {"status": "ok"}


app.include_router(company.router)
app.include_router(stock.router)
app.include_router(historical.router)
app.include_router(analysis.router)
