"""Automated tests (Yahoo calls mocked — no network required)."""

from datetime import date

from fastapi.testclient import TestClient

from app.main import app
from app.services import yahoo_finance as svc

client = TestClient(app)

MOCK_COMPANY = {
    "symbol": "AAPL",
    "name": "Apple Inc.",
    "business_summary": "Apple designs consumer electronics.",
    "industry": "Consumer Electronics",
    "sector": "Technology",
    "country": "United States",
    "website": "https://www.apple.com",
    "exchange": "NMS",
    "currency": "USD",
    "market": "us_market",
    "quote_type": "EQUITY",
    "officers": [{"name": "Tim Cook", "title": "CEO"}],
}

MOCK_STOCK = {
    "symbol": "AAPL",
    "name": "Apple Inc.",
    "market_state": "CLOSED",
    "regular_market_price": 232.14,
    "previous_close": 230.5,
    "price_change": 1.64,
    "price_change_percent": 0.7115,
    "day_high": 233.0,
    "day_low": 229.8,
    "fifty_two_week_high": 250.0,
    "fifty_two_week_low": 180.0,
    "volume": 50000000,
    "market_cap": 3500000000000,
    "currency": "USD",
    "exchange": "NMS",
}

MOCK_BARS = [
    {"date": "2025-01-02", "open": 100.0, "high": 102.0, "low": 99.0, "close": 101.0, "adj_close": 101.0, "volume": 1000},
    {"date": "2025-01-03", "open": 101.0, "high": 103.0, "low": 100.0, "close": 102.0, "adj_close": 102.0, "volume": 1100},
    {"date": "2025-01-06", "open": 102.0, "high": 104.0, "low": 101.0, "close": 103.0, "adj_close": 103.0, "volume": 1200},
]


def test_root_and_health():
    assert client.get("/").status_code == 200
    assert client.get("/health").json() == {"status": "ok"}


def test_docs_available():
    assert client.get("/docs").status_code == 200
    schema = client.get("/openapi.json").json()
    assert "/api/company/{symbol}" in schema["paths"]
    assert "/api/stock/{symbol}" in schema["paths"]
    assert "/api/historical" in schema["paths"]
    assert "/api/analysis" in schema["paths"]


def test_company_valid(monkeypatch):
    monkeypatch.setattr(svc, "get_company_info", lambda s: MOCK_COMPANY)
    r = client.get("/api/company/AAPL")
    assert r.status_code == 200
    body = r.json()
    assert body["symbol"] == "AAPL"
    assert body["officers"][0]["name"] == "Tim Cook"


def test_company_invalid_format():
    r = client.get("/api/company/AAPL!!!")
    assert r.status_code in (400, 404, 422)


def test_company_not_found(monkeypatch):
    from fastapi import HTTPException

    def _raise(s):
        raise HTTPException(status_code=404, detail="No data found for symbol 'ZZZZ'.")

    monkeypatch.setattr(svc, "get_company_info", _raise)
    assert client.get("/api/company/ZZZZ").status_code == 404


def test_stock_valid(monkeypatch):
    monkeypatch.setattr(svc, "get_stock_data", lambda s: MOCK_STOCK)
    r = client.get("/api/stock/AAPL")
    assert r.status_code == 200
    body = r.json()
    assert body["regular_market_price"] == 232.14
    assert body["price_change"] == 1.64


def test_stock_invalid_format():
    assert client.get("/api/stock/$$$").status_code in (400, 404, 422)


def test_historical_valid(monkeypatch):
    monkeypatch.setattr(svc, "get_history", lambda s, st, en: MOCK_BARS)
    r = client.post(
        "/api/historical",
        json={"symbol": "AAPL", "start_date": "2025-01-01", "end_date": "2025-01-10"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["count"] == 3
    assert body["data"][0]["date"] == "2025-01-02"


def test_historical_start_after_end():
    r = client.post(
        "/api/historical",
        json={"symbol": "AAPL", "start_date": "2025-06-30", "end_date": "2025-01-01"},
    )
    assert r.status_code == 422  # Pydantic model_validator rejection


def test_historical_bad_date_format():
    r = client.post(
        "/api/historical",
        json={"symbol": "AAPL", "start_date": "not-a-date", "end_date": "2025-01-01"},
    )
    assert r.status_code == 422


def test_historical_empty(monkeypatch):
    from fastapi import HTTPException

    def _raise(s, st, en):
        raise HTTPException(status_code=404, detail="No historical data found.")

    monkeypatch.setattr(svc, "get_history", _raise)
    r = client.post(
        "/api/historical",
        json={"symbol": "AAPL", "start_date": "2025-01-01", "end_date": "2025-01-02"},
    )
    assert r.status_code == 404


def test_analysis_math(monkeypatch):
    monkeypatch.setattr(svc, "get_history", lambda s, st, en: MOCK_BARS)
    r = client.post(
        "/api/analysis",
        json={"symbol": "AAPL", "start_date": "2025-01-01", "end_date": "2025-01-10"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["starting_price"] == 101.0
    assert body["ending_price"] == 103.0
    assert body["trading_days"] == 3
    assert body["moving_average_20"] is None  # not enough data
    assert body["moving_average_50"] is None
    assert body["trend"] in ("upward", "downward", "sideways")
    assert "not investment advice" in body["disclaimer"].lower()
    assert isinstance(body["insight"], str) and len(body["insight"]) > 0


def test_analysis_real_math_no_mock():
    """Pure-math check of get_analysis via monkeypatched history (25 bars -> MA20 present)."""
    bars = [
        {
            "date": f"2025-01-{i + 1:02d}",
            "open": 100.0 + i,
            "high": 101.0 + i,
            "low": 99.0 + i,
            "close": 100.0 + i,
            "adj_close": 100.0 + i,
            "volume": 1000,
        }
        for i in range(25)
    ]
    # Call the real function with monkeypatched get_history
    orig = svc.get_history
    svc.get_history = lambda s, st, en: bars
    try:
        out = svc.get_analysis("AAPL", date(2025, 1, 1), date(2025, 2, 1))
    finally:
        svc.get_history = orig
    assert out["trading_days"] == 25
    assert out["moving_average_20"] is not None
    assert out["moving_average_50"] is None
    assert out["trend"] == "upward"


def test_analysis_rejects_bad_range():
    r = client.post(
        "/api/analysis",
        json={"symbol": "AAPL", "start_date": "2025-06-30", "end_date": "2025-06-30"},
    )
    assert r.status_code == 422


def test_helpers_nan_safety():
    import math

    import numpy as np
    import pandas as pd

    from app.utils.helpers import clean_value, safe_float, validate_symbol_format

    assert clean_value(float("nan")) is None
    assert clean_value(np.float64("nan")) is None
    assert clean_value(pd.NaT) is None
    assert clean_value(np.int64(5)) == 5
    assert safe_float("bad") is None
    assert math.isclose(safe_float("3.5"), 3.5)
    assert validate_symbol_format("") is not None
    assert validate_symbol_format("AAPL") is None
