# Company & Market Data API

A REST API built with **Python + FastAPI** that serves **company information, current stock market data, historical market data, and analytical insights** using **Yahoo Finance data** via the `yfinance` library. No paid API key required.

## Overview

This project was built as an assessment submission. It exposes 4 robust endpoints:

| # | Endpoint | Description |
|---|----------|-------------|
| 1 | `GET /api/company/{symbol}` | Detailed company information (name, summary, industry, sector, country, website, exchange, currency, officers) |
| 2 | `GET /api/stock/{symbol}` | Current/latest market data (price, previous close, change, day range, 52-week range, volume, market cap) |
| 3 | `POST /api/historical` | Daily OHLCV history for a symbol + date range |
| 4 | `POST /api/analysis` | Descriptive statistics and data-driven insights over historical data |

Design goals: correctness, robustness (never crash on missing Yahoo fields), clean JSON, proper HTTP status codes, and easy evaluation.

## Features

- Yahoo Finance integration via `yfinance` (free, no API key)
- Pydantic request/response validation
- Graceful handling of invalid symbols, bad dates, empty history, missing fields, NaN/NaT, and Yahoo outages
- Price-change computation when Yahoo does not provide it directly
- JSON-safe serialization (no pandas/numpy objects leak into responses)
- Auto-generated Swagger docs at `/docs` and `/redoc`
- Automated tests with `pytest` + FastAPI `TestClient`

## Technology Stack

- Python 3.10+
- FastAPI
- Uvicorn (ASGI server)
- yfinance (Yahoo Finance)
- pandas / numpy (history handling)
- Pydantic v2 (validation)
- pytest + httpx (testing)

## Project Structure

```text
.
├── app/
│   ├── __init__.py
│   ├── main.py               # FastAPI app, routers, error handlers
│   ├── models.py             # Pydantic request/response models
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── company.py        # GET /api/company/{symbol}
│   │   ├── stock.py          # GET /api/stock/{symbol}
│   │   ├── historical.py     # POST /api/historical
│   │   └── analysis.py       # POST /api/analysis
│   ├── services/
│   │   ├── __init__.py
│   │   └── yahoo_finance.py  # yfinance calls + analysis math
│   └── utils/
│       ├── __init__.py
│       └── helpers.py        # symbol validation, NaN-safe converters
├── tests/
│   └── test_api.py           # automated tests
├── requirements.txt
├── README.md
├── .env.example
└── .gitignore
```

## Installation

### 1. Clone / unzip the project

```bash
cd API
```

### 2. Create a virtual environment

Windows (PowerShell):

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

## How to Run the API

```bash
uvicorn app.main:app --reload
```

Then open:

- API root: <http://127.0.0.1:8000/>
- Swagger UI: <http://127.0.0.1:8000/docs>
- ReDoc: <http://127.0.0.1:8000/redoc>
- OpenAPI JSON: <http://127.0.0.1:8000/openapi.json>

Custom host/port:

```bash
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

## API Endpoint Documentation

### 1. Company Information — `GET /api/company/{symbol}`

Returns normalized company details. Missing Yahoo fields are returned as `null` (officers as `[]`).

Example request:

```bash
curl http://127.0.0.1:8000/api/company/AAPL
```

Example response:

```json
{
  "symbol": "AAPL",
  "name": "Apple Inc.",
  "business_summary": "Apple Inc. designs, manufactures, ...",
  "industry": "Consumer Electronics",
  "sector": "Technology",
  "country": "United States",
  "website": "https://www.apple.com",
  "exchange": "NMS",
  "currency": "USD",
  "market": "us_market",
  "quote_type": "EQUITY",
  "officers": [{ "name": "Tim Cook", "title": "CEO" }]
}
```

Errors: `400` bad symbol format, `404` unknown symbol, `503` Yahoo unavailable.

### 2. Stock Market Data — `GET /api/stock/{symbol}`

Returns the latest quote. If Yahoo omits change fields, the API computes `price_change = price − previous_close` and `price_change_percent`.

Example request:

```bash
curl http://127.0.0.1:8000/api/stock/AAPL
```

Example response:

```json
{
  "symbol": "AAPL",
  "name": "Apple Inc.",
  "market_state": "CLOSED",
  "regular_market_price": 232.14,
  "previous_close": 230.5,
  "price_change": 1.64,
  "price_change_percent": 0.7115,
  "day_high": 233.0,
  "day_low": 229.8,
  "fifty_two_week_high": 250.0,
  "fifty_two_week_low": 180.0,
  "volume": 50000000,
  "market_cap": 3500000000000,
  "currency": "USD",
  "exchange": "NMS"
}
```

Unavailable numeric values are `null`.

### 3. Historical Market Data — `POST /api/historical`

Request body:

```json
{
  "symbol": "AAPL",
  "start_date": "2025-01-01",
  "end_date": "2025-06-30"
}
```

Example request:

```bash
curl -X POST http://127.0.0.1:8000/api/historical \
  -H "Content-Type: application/json" \
  -d "{\"symbol\": \"AAPL\", \"start_date\": \"2025-01-01\", \"end_date\": \"2025-06-30\"}"
```

Example response:

```json
{
  "symbol": "AAPL",
  "start_date": "2025-01-01",
  "end_date": "2025-06-30",
  "count": 124,
  "data": [
    {
      "date": "2025-01-02",
      "open": 243.0,
      "high": 245.0,
      "low": 242.0,
      "close": 244.0,
      "adj_close": 244.0,
      "volume": 48000000
    }
  ]
}
```

Validation: `start_date` must be before `end_date` (else `400`/`422`); unknown symbol or empty history returns `404`.

### 4. Analytical Insights — `POST /api/analysis`

Same request body as historical. Returns descriptive statistics plus a concise data-driven insight. **Not investment advice.**

Example request:

```bash
curl -X POST http://127.0.0.1:8000/api/analysis \
  -H "Content-Type: application/json" \
  -d "{\"symbol\": \"AAPL\", \"start_date\": \"2025-01-01\", \"end_date\": \"2025-06-30\"}"
```

Example response:

```json
{
  "symbol": "AAPL",
  "start_date": "2025-01-01",
  "end_date": "2025-06-30",
  "trading_days": 124,
  "starting_price": 243.0,
  "ending_price": 250.0,
  "highest_price": 255.0,
  "lowest_price": 220.0,
  "total_return_percent": 2.88,
  "average_close": 238.5,
  "volatility": 1.23,
  "average_volume": 52000000.0,
  "positive_days": 70,
  "negative_days": 50,
  "best_day": {"date": "2025-03-10", "change_percent": 3.5, "close": 240.0},
  "worst_day": {"date": "2025-04-01", "change_percent": -2.8, "close": 225.0},
  "trend": "upward",
  "moving_average_20": 249.1,
  "moving_average_50": 245.3,
  "insight": "From 2025-01-01 to 2025-06-30, AAPL showed a upward trend ...",
  "disclaimer": "This is analytical information based on historical data only, not investment advice or a prediction of future performance."
}
```

## Swagger Documentation

After starting the server:

- Swagger UI: <http://127.0.0.1:8000/docs>
- ReDoc: <http://127.0.0.1:8000/redoc>
- OpenAPI schema: <http://127.0.0.1:8000/openapi.json>

## Error Handling

| Status | Meaning | Example |
|--------|---------|---------|
| 200 | Success | Valid request |
| 400 | Invalid request | Bad symbol characters, `start_date >= end_date` in service layer |
| 404 | Not found | Unknown symbol, empty historical range |
| 422 | Validation error | Malformed JSON, wrong date format, missing fields (Pydantic) |
| 500 | Unexpected server error | Unhandled failure (should not happen) |
| 503 | External service failure | Yahoo Finance timeout/rate-limit |

Error shape:

```json
{"detail": "No data found for symbol 'XXXX'..."}
```

The server never crashes on: missing Yahoo fields, empty officer lists, empty history, NaN/NaT values, invalid symbols, or Yahoo outages.

## Analytical Methodology

Given daily closes \(c_1 \dots c_n\) and volumes:

- **Starting/ending price:** \(c_1\), \(c_n\)
- **Highest/lowest:** \(\max(c)\), \(\min(c)\)
- **Total return %:** \((c_n - c_1)/c_1 \times 100\)
- **Average close:** mean of closes
- **Volatility:** sample standard deviation of daily simple returns \((c_i - c_{i-1})/c_{i-1}\), expressed in % (0.0 for a single return, `null` when undefined)
- **Average volume:** mean of daily volumes
- **Positive/negative days:** sign of intraday move \((close − open)/open\); falls back to close-vs-previous-close when open is missing
- **Best/worst day:** max/min daily change % with date and close
- **Trend:** `upward` if return > 2%, `downward` if < −2%, else `sideways`
- **MA20 / MA50:** mean of last 20 / 50 closes; `null` when fewer bars exist
- **Insight:** template summarizing trend, return, volatility level (low < 1%, moderate < 2.5%, else high), MA position, and day counts — purely descriptive, no forecasts or recommendations.

## Testing Instructions

Run the automated suite (no network required — Yahoo calls are mocked):

```bash
pytest -v
```

What it covers:

- Health/root endpoints
- Company endpoint: valid symbol (mocked), invalid symbol format (400), unknown symbol (404)
- Stock endpoint: computed change fields, invalid symbol
- Historical endpoint: valid bars, `start_date >= end_date` rejection, bad date format (422), empty history (404)
- Analysis endpoint: math correctness on synthetic bars, trend/MA logic, disclaimer presence
- Docs/OpenAPI availability

Manual testing against live Yahoo Finance (requires internet):

```bash
uvicorn app.main:app --reload
curl http://127.0.0.1:8000/api/company/AAPL
curl http://127.0.0.1:8000/api/stock/AAPL
curl -X POST http://127.0.0.1:8000/api/historical -H "Content-Type: application/json" -d "{\"symbol\":\"AAPL\",\"start_date\":\"2025-01-01\",\"end_date\":\"2025-06-30\"}"
curl -X POST http://127.0.0.1:8000/api/analysis -H "Content-Type: application/json" -d "{\"symbol\":\"AAPL\",\"start_date\":\"2025-01-01\",\"end_date\":\"2025-06-30\"}"
```

Note: Yahoo Finance occasionally rate-limits unauthenticated requests (HTTP 429). If that happens, wait a minute and retry; the API surfaces it as a `503` with a clear message.
